﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Social_Media_Newby
{
    public partial class Form1 : Form
    {
        //Social_Media - Exam 3
        //Christopher Newby
        //CS 350 - Fall 2017
        //Professor Mark Seaman

        Test test_module = new Test();

        private int person_ID_count = 0;
        private int post_ID_count = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

 

        private void btnTest_Click(object sender, EventArgs e)
        {
            
            System_Mod one = new System_Mod();
            one.Reset_All_Data();
            //Run test battery via master test function
            test_module.Run_Master_Test();

            //test_module.Person_Registration_Test(1, "abc", "w", "w", "w");
            //MessageBox.Show(Data_Store.person_test_results[0]);

            //test_module.Person_Login_Test(1, "w");
            //MessageBox.Show(Data_Store.person_test_results[1]);

            /// test_module.Friend_List_Creation_Test();
            //MessageBox.Show(Data_Store.friend_test_results[0]);

            //Friend newOne = new Friend(1, 2);

            //test_module.New_Friendship_Test(newOne);
            //MessageBox.Show(Data_Store.friend_test_results[1]);

            //test_module.Remove_Friendship_Test(newOne);
            //MessageBox.Show(Data_Store.friend_test_results[2]);

            //test_module.List_All_Posts();
            //MessageBox.Show(Data_Store.post_test_results[0]);

            //Post test_post = new Post(1, "ChaCha", 1, 2, "Me likey do da cha cha");

            //test_module.Add_Topic_From_Friend(test_post);
            //MessageBox.Show(Data_Store.post_test_results[1]);

            //test_module.Remove_Topic_From_List(test_post);
            //MessageBox.Show(Data_Store.post_test_results[2]);

            //test_module.Reset_All_Data_Test();
            //MessageBox.Show(Data_Store.system_mod_test_results[0]);

            //one.Reset_All_Data();
            //test_module.Add_Persons_To_List();
            //test_module.Add_Friend_To_List();
            //test_module.Add_Post_To_List();
            //test_module.Export_Data_Test(Data_Store.person_list, Data_Store.friends_list, Data_Store.posts_list);
            //MessageBox.Show(Data_Store.system_mod_test_results[1]);

            //test_module.Import_Data_Test();
            //MessageBox.Show(Data_Store.system_mod_test_results[2]);
        }

        private void btnSaveNewUser_Click(object sender, EventArgs e)
        {
            person_ID_count += 1;
            Person person = new Person(person_ID_count, txtUserName.Text, txtUserPassword.Text, txtFirstName.Text, txtLastName.Text);
            Data_Store.person_list.Add(person);
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
            Application.Exit();
        }

        private void btnFriendSave_Click(object sender, EventArgs e)
        {
            Friend new_friend = new Friend(Convert.ToInt32(txtFriend1.Text), Convert.ToInt32(txtFriend1.Text));
            Data_Store.friends_list.Add(new_friend);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            post_ID_count += 1;
            Post new_p = new Post(post_ID_count, txtTopic.Text, Convert.ToInt32(txtAuthID.Text), Convert.ToInt32(txtRefID.Text), txtBody.Text);
            Data_Store.posts_list.Add(new_p);
        }
    }
}
